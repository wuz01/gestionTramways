#include<iostream>
#include"Tram.h"
#include"Ligne.h"
#include"Arret.h"
#include <cmath>


using namespace std;

Tram::Tram(): d_tx{0}, d_ty{0}, d_vitC{0}, d_sensDep{1}, d_numLigne{0}, d_tmp{0}, tsuiv{nullptr}, dern_arret{nullptr}
{}

Tram::~Tram()
{
    delete[] this;
}


void Tram::changerPosition(double nx, double ny)
{
	d_tx = nx;
	d_ty = ny;
}


bool Tram::validerArret(Arret *arret)
{
	return (d_tx == arret->d_x && d_ty == arret->d_y);
}


bool Tram::validerTemps(Arret *arret) const
{
	return (d_tmp >= arret->d_dureeMin);
}



double Tram::distanceDeuxPoints(double x1, double y1, double x2, double y2) const
{
	double dist = 0;
	double s1 = (y2 - y1)*(y2 - y1);
	double s2 = (x2 - x1)*(x2 - x1);
	dist = sqrt(s1 + s2);

	return dist;
}


void Tram::nouvellePos(Arret *arret, double& nx, double& ny)
{
	if( distanceDeuxPoints(d_tx,d_ty,arret->d_x, arret->d_y) <= d_vitC)
	{
		nx = arret->d_x;
		ny = arret->d_y;
	}

	else
	{
		double lamda = (arret->d_y - d_ty) / (arret->d_x - d_tx);
		double beta = d_ty - lamda*d_tx;
		double h = d_vitC;

		double A = 1;
		double B = (-1)*2*d_tx;
		double C = d_tx*d_tx - (h*h) / ((lamda*lamda) + 1);

		double delta = B*B - 4*A*C;
		double x1 = ( (-1)*B + sqrt(delta)) / 2*A;
		double y1 = lamda*x1 + beta;

		double x2 = ( (-1)*B - sqrt(delta)) / 2*A;
		double y2 = lamda*x2 + beta;

		if(distanceDeuxPoints(x1,y1,arret->d_x, arret->d_y) < distanceDeuxPoints(x2,y2,arret->d_x, arret->d_y))
		{
			nx = x1;
			ny = y1;
		}

		else
		{
			nx = x2;
			ny = y2;
		}
	}
}

Tram* Tram::getTSuiv()
{
    return tsuiv;
}

double Tram::getTX()
{
    return d_tx;
}

double Tram::getTY()
{
    return d_ty;
}

int Tram::getNumLigne()
{
    return d_numLigne;
}
