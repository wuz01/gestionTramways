#include<iostream>
#include"Ligne.h"
#include"Arret.h"
#include<vector>


using namespace std;

ligne::ligne(const vector<string>& TabNom,const vector<double>& TabX,const vector<double>& TabY, const vector<bool>& TabTerminus)
{
    d_tete = new Arret();

    Arret* arretC = d_tete;
    arretC->d_nom = TabNom[0];
    arretC->d_x = TabX[0];
    arretC->d_y = TabY[0];
    arretC->d_terminus = TabTerminus[0];

    Arret *nc = nullptr;

    for(int i=1;i<TabNom.size();i++)
    {
        nc = new Arret();
        nc->d_nom = TabNom[i];
        nc->d_x= TabX[i];
        nc->d_y= TabY[i];
        nc->d_terminus = TabTerminus[i];
        arretC->d_suiv=nc;
        arretC=nc;
    }

    arretC->d_suiv = d_tete;
}

ligne::~ligne()
{
    Arret* arretC = d_tete;

    if (arretC == nullptr)
    {
        return;
    }

    Arret *suiv = arretC->d_suiv;

    while (suiv != nullptr)
    {
        arretC->d_suiv = suiv->d_suiv;
        delete[] suiv;
        suiv = arretC->d_suiv;
    }


    delete[] arretC;
}

void ligne::GetnomsDesArrets()
{

    d_nomArrets.push_back(d_tete->d_nom);
    Arret *tmp = d_tete->d_suiv;
    while(tmp != d_tete)
    {
        d_nomArrets.push_back(tmp->d_nom);
        tmp=tmp->d_suiv;

    }

}

void ligne::afficheArrets()
{
    for(int i=0;i<d_nomArrets.size();i++)
    {
        cout<<d_nomArrets[i]<<endl;
    }
}

int ligne::taille() const
{
    Arret *tmpp = d_tete->d_suiv;
    int cpt=-1;
    while(tmpp->d_suiv != d_tete)
    {
        cpt=cpt+1;
        tmpp=tmpp->d_suiv;
    }
    return cpt;
}


Arret* ligne::terminus2()
{
    Arret *tmp = d_tete->d_suiv;
    while (!(tmp->d_terminus))
    {
        tmp = tmp->d_suiv;
    }

    return tmp;
}

Arret* ligne::getDTete()
{
    return d_tete;
}
