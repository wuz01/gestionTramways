#ifndef TRAM_H_INCLUDED
#define TRAM_H_INCLUDED

#include<iostream>
#include"Ligne.h"
#include"Arret.h"

class Tram
{


friend class ListeTrams;

    public:
        Tram* getTSuiv();
        double getTX();
        double getTY();
        int getNumLigne();

	private:

        Tram(); //constructeur

        ~Tram(); //destructeur

        void changerPosition(double nx, double ny); //change tx et ty en nx et ny

        bool validerArret(Arret *arret); //methode qui test si le tram est dans un arret

        bool validerTemps(Arret *arret) const; //methode qui compare le d_tmp et le temp minimale requis par l'arret, retourne TRUE si d_tmp depasse tmin

        double distanceDeuxPoints(double x1, double y1, double x2, double y2) const; //methode qui retourne la distance entre deux points

        void nouvellePos(Arret *arret, double& nx, double& ny); //methode qui calcule la nouvelle position du tram en tenant en compte la prochaine arret, ELLE MODIFIE nx ET ny



        double d_tx;

        double d_ty;

        double d_vitC; //vitesse courante

        bool d_sensDep; //sens de deplacement

        int d_numLigne; //numero de la Ligne associee

        int d_tmp; //le temps passe dans un arret

        Tram *tsuiv; //tram suivant

        Arret *dern_arret; //l' arret ou le tram se trouve OU la derniere arret dans laquelle il etait

};

#endif // TRAM_H_INCLUDED
