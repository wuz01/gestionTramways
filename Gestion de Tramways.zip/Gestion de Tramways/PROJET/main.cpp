#include <iostream>
#include <graphics.h>
#include <fstream>
#include <sstream>
#include <cmath>
#include <vector>
#include "Arret.h"
#include "Ligne.h"
#include "Tram.h"
#include "ListeTrams.h"

using namespace std;






int main()
{

    /** Initialisation des Lignes */

    vector<string> tabNom;
    vector<double> tabX;
    vector<double> tabY;
    vector<bool> tabTerminus;

    int nbl;

    cout << "Donnez le nombre de lignes : ";

    cin >> nbl;

    int i = 1;

    ligne *nl;

    vector<ligne*> vectLignes;

    tabNom.clear();
    tabX.clear();
    tabY.clear();
    tabTerminus.clear();
    vectLignes.clear();

    while (i <= nbl)
    {
        string nomFichier;
        cout << "Donnez le nom du fichier pour la ligne " << i << " : ";
        cin >> nomFichier;
        ifstream fichier(nomFichier);

        string lignee;
        double d;
        double d1;
        bool ter;

        while(getline(fichier,lignee))
        {

            tabNom.push_back(lignee);

            getline(fichier,lignee);
            istringstream iss(lignee);
            iss>>d;
            tabX.push_back(d);

            getline(fichier,lignee);
            istringstream(lignee)>> d1;
            tabY.push_back(d1);

            getline(fichier,lignee);
            istringstream(lignee)>> ter;
            tabTerminus.push_back(ter);

        }

        nl = new ligne(tabNom,tabX,tabY, tabTerminus);

        vectLignes.push_back(nl);

        tabNom.clear();
        tabX.clear();
        tabY.clear();
        tabTerminus.clear();

        i++;
    }

    /** Initialisation des Trams */
    ListeTrams *lt = new ListeTrams();
    lt->initialiserTrams(vectLignes);


    /** Representation graphique et boucle principale */
    int gd = DETECT , gm;
    initgraph(&gd ,&gm , "C:\\TC\\BGI" );

    delay(500);

    Arret *tmp;

    Tram *tramC = lt->getDTete();

    i = 0;

    while (i < 100)
    {
        ++i;
        tramC = lt->getDTete();

        cleardevice();

        int k = 0;

        while (k < vectLignes.size())
        {
            int j = 0;

            tmp = vectLignes[k]->getDTete();

            while (j < vectLignes[k]->taille())
            {
                circle(tmp->getDX(), tmp->getDY(), 10);
                line(tmp->getDX(), tmp->getDY(), tmp->getDSuiv()->getDX(), tmp->getDSuiv()->getDY());
                tmp = tmp->getDSuiv();
                ++j;
            }
            ++k;
        }

        while(tramC != nullptr)
        {
            lt->avancerTram(tramC, vectLignes[tramC->getNumLigne() - 1]);
            bar(tramC->getTX() - 5,tramC->getTY() + 5,tramC->getTX() + 5,tramC->getTY() - 5);
            tramC = tramC->getTSuiv();
        }

        delay(80);

    }

    lt->~ListeTrams();
    tabNom.clear();
    tabX.clear();
    tabY.clear();
    tabTerminus.clear();
    vectLignes.clear();


    return 0;
}
