#ifndef LIGNE_H_INCLUDED
#define LIGNE_H_INCLUDED

#include<iostream>
#include<vector>
#include"Arret.h"

using namespace std;


class ligne{

    friend class ListeTrams;

public:
    ligne(const std::vector<string>& TabNom,const std::vector<double>& TabX,const std::vector<double>& TabY, const vector<bool>& TabTerminus);
    ~ligne();
    void GetnomsDesArrets();
    void afficheArrets();
    int taille() const ;
    void DistanceEntreArrets(vector<double>& d_nomArrets);
    Arret* terminus2();
    Arret* getDTete();
private:
    std::vector<string> d_nomArrets;
    Arret* d_tete;
};

#endif // LIGNE_H_INCLUDED
