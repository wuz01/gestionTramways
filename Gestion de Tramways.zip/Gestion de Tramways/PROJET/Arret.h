#ifndef ARRET_H_INCLUDED
#define ARRET_H_INCLUDED

#include<iostream>

using namespace std;

class Arret{
    friend class ligne;
    friend class Tram;
    friend class ListeTrams;

public:
    double getDX();
    double getDY();
    Arret* getDSuiv();

private :
    Arret();
    ~Arret();
    std::string d_nom;
    double d_x;
    double d_y;
    int d_dureeMin=5;
    Arret *d_suiv;
    bool d_terminus;
};


#endif // ARRET_H_INCLUDED
