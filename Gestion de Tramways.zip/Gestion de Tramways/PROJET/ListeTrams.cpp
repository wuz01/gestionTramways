#include<iostream>
#include <vector>
#include "ListeTrams.h"
#include"Ligne.h"
#include"Arret.h"
#include"Tram.h"

using namespace std;

ListeTrams::ListeTrams(): d_vitMax{20}, d_distMin{10}, d_tete{nullptr}
{}

ListeTrams::~ListeTrams()
{
    Tram *tCrt = d_tete;

    if (tCrt == nullptr)
    {
        return;
    }

    Tram *suiv = tCrt->tsuiv;

    while (suiv != nullptr)
    {
        tCrt->tsuiv = suiv->tsuiv;
        delete[] suiv;
        suiv = tCrt->tsuiv;
    }


    delete[] tCrt;
}

int ListeTrams::saisieTrams(int nbl) const
{
    cout << "Entrez le nombre de trams (au plus 2 par ligne, nb de lignes = " << nbl << ") : ";
    int nbt;
    cin >> nbt;

    while (nbt < 0 || nbt > 2*nbl)
    {
        cout << endl;
        cout << "Nombre pas valide, re-entrez le nombre de trams : ";
        cin >> nbt;
    }

    return nbt;
}

void ListeTrams::insererTram()
{
    Tram *tCrt = d_tete;

    if (tCrt == nullptr)
    {
        d_tete = new Tram();
    }

    else
    {
        while (tCrt->tsuiv != nullptr)
        {
            tCrt = tCrt->tsuiv;
        }

        tCrt->tsuiv = new Tram();
    }
}

void ListeTrams::initialiserTrams(const vector<ligne*> &lignes)
{
    int nbl = lignes.size();

    int nbt = saisieTrams(nbl);

    int i;

    for (i = 0; i < nbt; ++i)
    {
        insererTram();
    }


    Tram *tCrt = d_tete;
    i = 0;

    while (tCrt != nullptr && i < nbl)
    {
        tCrt->dern_arret = lignes[i]->d_tete;
        tCrt->changerPosition(tCrt->dern_arret->d_x, tCrt->dern_arret->d_y);
        tCrt->d_numLigne = i+1;

        tCrt = tCrt->tsuiv;
        ++i;
    }

    i = 0;

    while (tCrt != nullptr && i < nbl)
    {
        tCrt->dern_arret = lignes[i]->terminus2();
        tCrt->changerPosition(tCrt->dern_arret->d_x, tCrt->dern_arret->d_y);
        tCrt->d_numLigne = i+1;
        tCrt->d_sensDep = 0;

        tCrt = tCrt->tsuiv;
        ++i;
    }
}


bool ListeTrams::validerBloque(Arret *arret, double nx, double ny, bool sensDep) const
{
    Tram *tCrt = d_tete;

    while (tCrt != nullptr)
    {
        if (tCrt->d_tx == arret->d_x && tCrt->d_ty == arret->d_y && sensDep == tCrt->d_sensDep)
        {
            if( tCrt->distanceDeuxPoints(nx,ny,tCrt->d_tx,tCrt->d_ty) < d_distMin)
            {
                return true;
            }
        }

        tCrt = tCrt->tsuiv;
    }

    return false;
}


void ListeTrams::avancerTram(Tram *tram, ligne* ligne) const
{
    Arret *DernArret = tram->dern_arret;
    Arret *SuivArret = DernArret->d_suiv;


//valider si le tram est dans une arret
    if (tram->validerArret(DernArret))
    {

//valider s' il a deppasse le temps requis de cette arret
        if (tram->validerTemps(DernArret))
        {
            tram->d_tmp = 0;
//valider s' il faut changer le sens de deplacement
            if (DernArret->d_terminus)
            {
                tram->d_sensDep = !(tram->d_sensDep);
            }

            tram->d_vitC = d_vitMax;
            double nx = 0; double ny = 0;

            tram->nouvellePos(SuivArret, nx, ny);

//valider si son deplacement est bloque par un autre tram
            if (validerBloque(SuivArret, nx, ny, tram->d_sensDep))
            {
                return;
            }

            else
            {
                tram->d_tmp = 0;
                tram->changerPosition(nx,ny);

//valider si le tram a arrive a la prochaine arret
                if (tram->validerArret(SuivArret))
                {
                    tram->dern_arret = SuivArret;
                    tram->d_vitC = 0;
                }
            }
        }

        else
        {
            tram->d_tmp += 1;
            return;
        }
    }

    else
    {
        double nx = 0; double ny = 0;

        tram->nouvellePos(SuivArret, nx, ny);

        if (validerBloque(SuivArret, nx, ny, tram->d_sensDep))
        {
            return;
        }

        else
        {
            tram->changerPosition(nx,ny);

            if (tram->validerArret(SuivArret))
            {
                tram->dern_arret = SuivArret;
                tram->d_vitC = 0;
            }
        }
    }
}


Tram* ListeTrams::getDTete()
{
    return d_tete;
}
