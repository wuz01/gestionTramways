#ifndef LISTETRAMS_H_INCLUDED
#define LISTETRAMS_H_INCLUDED

#include<iostream>
#include <vector>
#include"Ligne.h"
#include"Arret.h"
#include"Tram.h"

class ListeTrams

{

	public:

ListeTrams(); //constructeur de liste vide

~ListeTrams(); //destructeur

void initialiserTrams(const vector<ligne*> &lignes); //methode qui met tous les trams aux positions initiales et initialise ses variables

void avancerTram(Tram *tram, ligne* ligne) const; //methode qui effectue le deplacement pour 1 tram

Tram* getDTete();



	private:

int saisieTrams(int nbl) const; //methode qui demande et valide un nombre de trams, retourne le resultat

void insererTram(); //methode qui creer un nouveau tram et le rajout dans la liste

bool validerBloque(Arret *arret, double nx, double ny, bool sensDep) const; //methode qui test si un tram ne peut pas s'avancer a cause d' un autre tram


double d_vitMax; //vitesse max pour les trams

double d_distMin; //distance minimale entre les trams

Tram *d_tete; //le premier tram de la liste

};


#endif // LISTETRAMS_H_INCLUDED
