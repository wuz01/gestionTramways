#include<iostream>
#include"Arret.h"

Arret::Arret():d_nom{" "}, d_x{0},d_y{0}, d_suiv{nullptr}, d_terminus{false}
{}

Arret::~Arret()
{
    delete[] this;
}

double Arret::getDX()
{
    return d_x;
}

double Arret::getDY()
{
    return d_y;
}

Arret* Arret::getDSuiv()
{
    return d_suiv;
}
